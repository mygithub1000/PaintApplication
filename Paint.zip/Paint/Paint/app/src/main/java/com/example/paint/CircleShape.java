package com.example.paint;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class CircleShape extends AreaShape {

    private int xEnd;
    private int yEnd;
    private double radius;

    public CircleShape(int x, int y, String color,int width, boolean fill) {
        super(x, y, color,width,fill);

        xEnd = x;
        yEnd = y;
    }

    @Override
    public void updatePoint(int xe, int ye) {
        xEnd = xe;
        yEnd = ye;
        radius = (int)(Math.sqrt(Math.pow(xEnd - x, 2) + Math.pow(yEnd - y, 2)));
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        super.draw(canvas, paint);
        if(fill==true)
            paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(x, y, (float) radius, paint);
    }
    public double GetArea(){return Math.pow(radius, 2) * Math.PI;}
}